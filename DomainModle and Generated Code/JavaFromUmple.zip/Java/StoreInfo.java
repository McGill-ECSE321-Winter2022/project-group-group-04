/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.sql.Time;

// line 36 "model.ump"
// line 129 "model.ump"
public class StoreInfo
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //StoreInfo Attributes
  private String address;
  private String telaphone;
  private String email;
  private Time startHour;
  private Time endHour;
  private Time weekendStartHour;
  private Time weekendEndHour;

  //StoreInfo Associations
  private StoreOwner storeOwner;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public StoreInfo(String aAddress, String aTelaphone, String aEmail, Time aStartHour, Time aEndHour, Time aWeekendStartHour, Time aWeekendEndHour, StoreOwner aStoreOwner)
  {
    address = aAddress;
    telaphone = aTelaphone;
    email = aEmail;
    startHour = aStartHour;
    endHour = aEndHour;
    weekendStartHour = aWeekendStartHour;
    weekendEndHour = aWeekendEndHour;
    if (aStoreOwner == null || aStoreOwner.getStoreInfo() != null)
    {
      throw new RuntimeException("Unable to create StoreInfo due to aStoreOwner. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    storeOwner = aStoreOwner;
  }

  public StoreInfo(String aAddress, String aTelaphone, String aEmail, Time aStartHour, Time aEndHour, Time aWeekendStartHour, Time aWeekendEndHour, String aEmailForStoreOwner, String aNameForStoreOwner, String aPasswordForStoreOwner, UserType aTypeForStoreOwner)
  {
    address = aAddress;
    telaphone = aTelaphone;
    email = aEmail;
    startHour = aStartHour;
    endHour = aEndHour;
    weekendStartHour = aWeekendStartHour;
    weekendEndHour = aWeekendEndHour;
    storeOwner = new StoreOwner(aEmailForStoreOwner, aNameForStoreOwner, aPasswordForStoreOwner, aTypeForStoreOwner, this);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setAddress(String aAddress)
  {
    boolean wasSet = false;
    address = aAddress;
    wasSet = true;
    return wasSet;
  }

  public boolean setTelaphone(String aTelaphone)
  {
    boolean wasSet = false;
    telaphone = aTelaphone;
    wasSet = true;
    return wasSet;
  }

  public boolean setEmail(String aEmail)
  {
    boolean wasSet = false;
    email = aEmail;
    wasSet = true;
    return wasSet;
  }

  public boolean setStartHour(Time aStartHour)
  {
    boolean wasSet = false;
    startHour = aStartHour;
    wasSet = true;
    return wasSet;
  }

  public boolean setEndHour(Time aEndHour)
  {
    boolean wasSet = false;
    endHour = aEndHour;
    wasSet = true;
    return wasSet;
  }

  public boolean setWeekendStartHour(Time aWeekendStartHour)
  {
    boolean wasSet = false;
    weekendStartHour = aWeekendStartHour;
    wasSet = true;
    return wasSet;
  }

  public boolean setWeekendEndHour(Time aWeekendEndHour)
  {
    boolean wasSet = false;
    weekendEndHour = aWeekendEndHour;
    wasSet = true;
    return wasSet;
  }

  public String getAddress()
  {
    return address;
  }

  public String getTelaphone()
  {
    return telaphone;
  }

  public String getEmail()
  {
    return email;
  }

  public Time getStartHour()
  {
    return startHour;
  }

  public Time getEndHour()
  {
    return endHour;
  }

  public Time getWeekendStartHour()
  {
    return weekendStartHour;
  }

  public Time getWeekendEndHour()
  {
    return weekendEndHour;
  }
  /* Code from template association_GetOne */
  public StoreOwner getStoreOwner()
  {
    return storeOwner;
  }

  public void delete()
  {
    StoreOwner existingStoreOwner = storeOwner;
    storeOwner = null;
    if (existingStoreOwner != null)
    {
      existingStoreOwner.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "address" + ":" + getAddress()+ "," +
            "telaphone" + ":" + getTelaphone()+ "," +
            "email" + ":" + getEmail()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "startHour" + "=" + (getStartHour() != null ? !getStartHour().equals(this)  ? getStartHour().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "endHour" + "=" + (getEndHour() != null ? !getEndHour().equals(this)  ? getEndHour().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "weekendStartHour" + "=" + (getWeekendStartHour() != null ? !getWeekendStartHour().equals(this)  ? getWeekendStartHour().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "weekendEndHour" + "=" + (getWeekendEndHour() != null ? !getWeekendEndHour().equals(this)  ? getWeekendEndHour().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "storeOwner = "+(getStoreOwner()!=null?Integer.toHexString(System.identityHashCode(getStoreOwner())):"null");
  }
}