/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.sql.Time;
import java.util.*;

// line 92 "model.ump"
// line 164 "model.ump"
public class DeliveryTimeSlots extends TimeSlots
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public DeliveryTimeSlots(Time aStartTime, Time aEndTime, int aMaxOrderPerSlot)
  {
    super(aStartTime, aEndTime, aMaxOrderPerSlot);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}