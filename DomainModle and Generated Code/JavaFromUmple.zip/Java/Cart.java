/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.util.*;

// line 49 "model.ump"
// line 134 "model.ump"
public class Cart
{

  //------------------------
  // ENUMERATIONS
  //------------------------

  public enum ShoppingType { Delivery, Pickup }

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Cart Attributes
  private int cartID;
  private ShoppingType type;

  //Cart Associations
  private Customer customer;
  private List<CartItem> cartItems;
  private TimeSlots timeSlots;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Cart(int aCartID, ShoppingType aType, Customer aCustomer, TimeSlots aTimeSlots)
  {
    cartID = aCartID;
    type = aType;
    if (aCustomer == null || aCustomer.getCart() != null)
    {
      throw new RuntimeException("Unable to create Cart due to aCustomer. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    customer = aCustomer;
    cartItems = new ArrayList<CartItem>();
    boolean didAddTimeSlots = setTimeSlots(aTimeSlots);
    if (!didAddTimeSlots)
    {
      throw new RuntimeException("Unable to create cart due to timeSlots. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
  }

  public Cart(int aCartID, ShoppingType aType, String aEmailForCustomer, String aNameForCustomer, String aPasswordForCustomer, UserType aTypeForCustomer, String aAddressForCustomer, String aPhoneForCustomer, TimeSlots aTimeSlots)
  {
    cartID = aCartID;
    type = aType;
    customer = new Customer(aEmailForCustomer, aNameForCustomer, aPasswordForCustomer, aTypeForCustomer, aAddressForCustomer, aPhoneForCustomer, this);
    cartItems = new ArrayList<CartItem>();
    boolean didAddTimeSlots = setTimeSlots(aTimeSlots);
    if (!didAddTimeSlots)
    {
      throw new RuntimeException("Unable to create cart due to timeSlots. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setCartID(int aCartID)
  {
    boolean wasSet = false;
    cartID = aCartID;
    wasSet = true;
    return wasSet;
  }

  public boolean setType(ShoppingType aType)
  {
    boolean wasSet = false;
    type = aType;
    wasSet = true;
    return wasSet;
  }

  public int getCartID()
  {
    return cartID;
  }

  public ShoppingType getType()
  {
    return type;
  }
  /* Code from template association_GetOne */
  public Customer getCustomer()
  {
    return customer;
  }
  /* Code from template association_GetMany */
  public CartItem getCartItem(int index)
  {
    CartItem aCartItem = cartItems.get(index);
    return aCartItem;
  }

  public List<CartItem> getCartItems()
  {
    List<CartItem> newCartItems = Collections.unmodifiableList(cartItems);
    return newCartItems;
  }

  public int numberOfCartItems()
  {
    int number = cartItems.size();
    return number;
  }

  public boolean hasCartItems()
  {
    boolean has = cartItems.size() > 0;
    return has;
  }

  public int indexOfCartItem(CartItem aCartItem)
  {
    int index = cartItems.indexOf(aCartItem);
    return index;
  }
  /* Code from template association_GetOne */
  public TimeSlots getTimeSlots()
  {
    return timeSlots;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfCartItems()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public CartItem addCartItem(int aQuantity, Order aOrder, Product aProduct)
  {
    return new CartItem(aQuantity, aOrder, aProduct, this);
  }

  public boolean addCartItem(CartItem aCartItem)
  {
    boolean wasAdded = false;
    if (cartItems.contains(aCartItem)) { return false; }
    Cart existingCart = aCartItem.getCart();
    boolean isNewCart = existingCart != null && !this.equals(existingCart);
    if (isNewCart)
    {
      aCartItem.setCart(this);
    }
    else
    {
      cartItems.add(aCartItem);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeCartItem(CartItem aCartItem)
  {
    boolean wasRemoved = false;
    //Unable to remove aCartItem, as it must always have a cart
    if (!this.equals(aCartItem.getCart()))
    {
      cartItems.remove(aCartItem);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addCartItemAt(CartItem aCartItem, int index)
  {  
    boolean wasAdded = false;
    if(addCartItem(aCartItem))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfCartItems()) { index = numberOfCartItems() - 1; }
      cartItems.remove(aCartItem);
      cartItems.add(index, aCartItem);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveCartItemAt(CartItem aCartItem, int index)
  {
    boolean wasAdded = false;
    if(cartItems.contains(aCartItem))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfCartItems()) { index = numberOfCartItems() - 1; }
      cartItems.remove(aCartItem);
      cartItems.add(index, aCartItem);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addCartItemAt(aCartItem, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetOneToMany */
  public boolean setTimeSlots(TimeSlots aTimeSlots)
  {
    boolean wasSet = false;
    if (aTimeSlots == null)
    {
      return wasSet;
    }

    TimeSlots existingTimeSlots = timeSlots;
    timeSlots = aTimeSlots;
    if (existingTimeSlots != null && !existingTimeSlots.equals(aTimeSlots))
    {
      existingTimeSlots.removeCart(this);
    }
    timeSlots.addCart(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Customer existingCustomer = customer;
    customer = null;
    if (existingCustomer != null)
    {
      existingCustomer.delete();
    }
    for(int i=cartItems.size(); i > 0; i--)
    {
      CartItem aCartItem = cartItems.get(i - 1);
      aCartItem.delete();
    }
    TimeSlots placeholderTimeSlots = timeSlots;
    this.timeSlots = null;
    if(placeholderTimeSlots != null)
    {
      placeholderTimeSlots.removeCart(this);
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "cartID" + ":" + getCartID()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "type" + "=" + (getType() != null ? !getType().equals(this)  ? getType().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "customer = "+(getCustomer()!=null?Integer.toHexString(System.identityHashCode(getCustomer())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "timeSlots = "+(getTimeSlots()!=null?Integer.toHexString(System.identityHashCode(getTimeSlots())):"null");
  }
}