/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.sql.Time;
import java.util.*;

// line 97 "model.ump"
// line 169 "model.ump"
public class PickUpTimeSlots extends TimeSlots
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PickUpTimeSlots(Time aStartTime, Time aEndTime, int aMaxOrderPerSlot)
  {
    super(aStartTime, aEndTime, aMaxOrderPerSlot);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}